from flask import Flask, request, jsonify, render_template
from model import SpellGrammarChecker
import os

# Set Java path explicitly
os.environ["JAVA_HOME"] = "E:\\52555"
os.environ["PATH"] = "E:\\52555\\bin" + os.pathsep + os.environ["PATH"]

app = Flask(__name__)

# Initialize SpellGrammarChecker
checker = SpellGrammarChecker()

@app.route('/')
def home():
    return render_template("index.html")
@app.route('/spell_check', methods=['POST'])
def spell_check():
    text = request.form['text']
    corrected_text, corrections = checker.correct_spelling_and_grammar(text)  # Ensure both values are returned
    
    return render_template("index.html", original_text=text, corrected_text=corrected_text, corrections=corrections)
  # Ensure index.html exists in 'templates' folder

if __name__ == '__main__':
    app.run(debug=True)
