import spacy
from happytransformer import HappyTextToText, TTSettings
from language_tool_python import LanguageTool
from spellchecker import SpellChecker  

# Load spaCy model
nlp = spacy.load("en_core_web_sm")

# Load Happy Transformer for deep grammar correction
happy_tt = HappyTextToText("T5", "vennify/t5-base-grammar-correction")
settings = TTSettings(num_beams=5, min_length=1, max_length=50)  # Set max_length to avoid excessive repetition

# Initialize SpellChecker
spell = SpellChecker()

class SpellGrammarChecker:
    def __init__(self):
        self.grammar_tool = LanguageTool("en-US")

    def correct_spelling(self, text):
        """Corrects spelling mistakes using pyspellchecker"""
        words = text.split()
        corrected_words = [spell.correction(word) if spell.correction(word) else word for word in words]
        return " ".join(corrected_words)

    def correct_spelling_and_grammar(self, text):
        if not text.strip():
            return text, []  # Return original text if empty

        # Step 1: Apply spell correction
        spell_corrected_text = self.correct_spelling(text)

        # Step 2: Use LanguageTool for grammar correction
        lt_corrected_text = self.grammar_tool.correct(spell_corrected_text)
        
        if not lt_corrected_text.strip():
            return text, []  # Return original text if correction is empty

        # Step 3: Use Transformer model for final correction
        transformer_output = happy_tt.generate_text(lt_corrected_text, args=settings)
        corrected_text = transformer_output.text.strip()

        # **Prevent Repeated Phrases**
        words = corrected_text.split()
        unique_words = []
        for word in words:
            if len(unique_words) == 0 or word != unique_words[-1]:  
                unique_words.append(word)
        corrected_text = " ".join(unique_words)

        corrections = [(text, corrected_text)] if text != corrected_text else []
        return corrected_text, corrections

# Example Usage
if __name__ == "__main__":
    checker = SpellGrammarChecker()
    sample_text = "entr yr textttt"

    # Correct spelling & grammar together
    corrected_text, corrections = checker.correct_spelling_and_grammar(sample_text)
    print("Corrected Text:", corrected_text)
    print("Corrections:", corrections)
